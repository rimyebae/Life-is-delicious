package qnacomment;

public class QnaComment {
	
	private int qnaID;
	private String userID;
	private int qcomntID;
	private String qcomntDate;
	private String qcomntContent;
	private int qcomntAvailable;
	
	
	
	
	
	public int getQnaID() {
		return qnaID;
	}
	public void setQnaID(int qnaID) {
		this.qnaID = qnaID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public int getQcomntID() {
		return qcomntID;
	}
	public void setQcomntID(int qcomntID) {
		this.qcomntID = qcomntID;
	}
	public String getQcomntDate() {
		return qcomntDate;
	}
	public void setQcomntDate(String qcomntDate) {
		this.qcomntDate = qcomntDate;
	}
	public String getQcomntContent() {
		return qcomntContent;
	}
	public void setQcomntContent(String qcomntContent) {
		this.qcomntContent = qcomntContent;
	}
	public int getQcomntAvailable() {
		return qcomntAvailable;
	}
	public void setQcomntAvailable(int qcomntAvailable) {
		this.qcomntAvailable = qcomntAvailable;
	}

	

}
