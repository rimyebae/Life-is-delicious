package qna;

public class Qna {
	
	private int qnaID;
	private String userID;
	private String qnaDate;
	private String qnaSort;
	private String qnaTitle;
	private String qnaContent;
	private int qnaStatus;
	private int qnaAvailable;
	
	
	
	
	
	public int getQnaID() {
		return qnaID;
	}
	public void setQnaID(int qnaID) {
		this.qnaID = qnaID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getQnaDate() {
		return qnaDate;
	}
	public void setQnaDate(String qnaDate) {
		this.qnaDate = qnaDate;
	}
	public String getQnaSort() {
		return qnaSort;
	}
	public void setQnaSort(String qnaSort) {
		this.qnaSort = qnaSort;
	}
	public String getQnaTitle() {
		return qnaTitle;
	}
	public void setQnaTitle(String qnaTitle) {
		this.qnaTitle = qnaTitle;
	}
	public String getQnaContent() {
		return qnaContent;
	}
	public void setQnaContent(String qnaContent) {
		this.qnaContent = qnaContent;
	}
	public int getQnaStatus() {
		return qnaStatus;
	}
	public void setQnaStatus(int qnaStatus) {
		this.qnaStatus = qnaStatus;
	}
	public int getQnaAvailable() {
		return qnaAvailable;
	}
	public void setQnaAvailable(int qnaAvailable) {
		this.qnaAvailable = qnaAvailable;
	}
	
	
	

}
