package placecomment;

public class PlaceComment {
	
	private int placeID;
	private String userID;
	private int pcomntID;
	private String pcomntDate;
	private int pcomntPoint;
	private String pcomntContent;
	private int pcomntAvailable;
	
	
	
	public int getPlaceID() {
		return placeID;
	}
	public void setPlaceID(int placeID) {
		this.placeID = placeID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public int getPcomntID() {
		return pcomntID;
	}
	public void setPcomntID(int pcomntID) {
		this.pcomntID = pcomntID;
	}
	public String getPcomntDate() {
		return pcomntDate;
	}
	public void setPcomntDate(String pcomntDate) {
		this.pcomntDate = pcomntDate;
	}
	public int getPcomntPoint() {
		return pcomntPoint;
	}
	public void setPcomntPoint(int pcomntPoint) {
		this.pcomntPoint = pcomntPoint;
	}
	public String getPcomntContent() {
		return pcomntContent;
	}
	public void setPcomntContent(String pcomntContent) {
		this.pcomntContent = pcomntContent;
	}
	public int getPcomntAvailable() {
		return pcomntAvailable;
	}
	public void setPcomntAvailable(int pcomntAvailable) {
		this.pcomntAvailable = pcomntAvailable;
	}
	
	
	

	

}
